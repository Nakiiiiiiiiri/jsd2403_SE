create definer = root@localhost view v_subject_teacher_salary_info as
select `tedu`.`teacher`.`subject_id`  AS `subject_id`,
       max(`tedu`.`teacher`.`salary`) AS `sal_max`,
       min(`tedu`.`teacher`.`salary`) AS `sal_min`,
       sum(`tedu`.`teacher`.`salary`) AS `sal_sum`,
       avg(`tedu`.`teacher`.`salary`) AS `sal_avg`
from `tedu`.`teacher`
group by `tedu`.`teacher`.`subject_id`;

